$(document).ready(function(){
	$('#tb-reclamacoes').dataTable();
});